public class Cliente {

    private String nome;
    private String cpf;
    private Endereco endereco;

    public Cliente(String nome, String cpf, String rua, int numero, String cidade) {
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = new Endereco(rua, numero, cidade);
    }

   
}